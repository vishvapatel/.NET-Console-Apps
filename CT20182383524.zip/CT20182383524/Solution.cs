using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution
{
    class Program
    {
        static void Main(string[] args)
        {
            Apartment manager = new Apartment();

            int n = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int flatno = int.Parse(Console.ReadLine());
                int flatSize = int.Parse(Console.ReadLine());
                String ownerName = Console.ReadLine();
                String status = Console.ReadLine();
                int noOfPeople = int.Parse(Console.ReadLine());
                manager.residents.Add(new Resident(flatno, flatSize, ownerName, status, noOfPeople));
            }
            int choice = Convert.ToInt32(Console.ReadLine());

            // Enter code for handling the 3 operations
            //Choice 1 for FindSeatNoWithRowFromBoardingDetails
            //Choice 2 for CountResidentsOfGivenTravelClass
            //choice 3 for AddResident

            switch(choice)
            {
                case 1:
                    List<string> statusCount = manager.FindStatusWiseTotalNoOfPeople();
                    if(statusCount.Count == 1)
                    {
                        Console.WriteLine("Invalid Data");
                    }
                    else
                    {
                        foreach(var s in statusCount)
                        {
                            Console.WriteLine(s);
                        }
                    }
                break;
                
                case 2:
                    int flatNo = Convert.ToInt16(Console.ReadLine()); 
                    Resident resident = manager.FindResidentByFlatNo(flatNo);
                    if(resident == null)
                    {
                        Console.WriteLine("No resident found");
                    }
                    else
                    {
                        Console.WriteLine($"{resident.ownerName},{resident.noOfPeople}");
                    }
                break;
                
                case 3:
                    int fltno = int.Parse(Console.ReadLine());
                    int fltSize = int.Parse(Console.ReadLine());
                    string ownrName = Console.ReadLine();
                    string sttus = Console.ReadLine();
                    int noOfPeple = int.Parse(Console.ReadLine());
                    manager.AddResident(fltno, fltSize, ownrName, sttus, noOfPeple);
                break;
            }
             #region solution1
             
             #endregion
        }
    }
    // Create class Resident with the required property and constructor
    #region solution2
    class Resident
    {
        public int flatNo {get; set;}
        public int flatSize {get; set;}
        public string ownerName {get; set;}
        public string status {get; set;}
        public int noOfPeople {get; set;}

        //Constructor to be called while adding a resident
        public Resident(int fltno, int fltsze, string ownrname, string sttus, int noofpeple)
        {
            flatNo = fltno;
            flatSize = fltsze;
            ownerName = ownrname;
            status = sttus;
            noOfPeople = noofpeple;
        }
    }
    #endregion

    // Create class Apartment as per given specification
    // Write code for all 3 methods that would perform operations handled in solution1
    #region solution3
    
    class Apartment
    {
        public List<Resident> residents = new List<Resident>();
        private static Dictionary<int, int> allowedResidents = new Dictionary<int, int>();
        public Apartment()
        {
            //Adding No of residents allowed per flatsize to a dictionary for validation.
            allowedResidents.Add(1, 2);
            allowedResidents.Add(2,4);
            allowedResidents.Add(3, 6);
        }
        public void AddResident(int fltno, int fltsze, string ownrname, string sttus, int noofpeple)
        {
            //Checks if the no of residents are vlaid for the requested flat size
            if(noofpeple > allowedResidents[fltsze]){
                Console.WriteLine("Selected BHK size is invalid");
            }
            //Checks if already occupied
            else if(residents.Any(r => r.flatSize == fltsze)) 
            {
                Console.WriteLine($"{fltsze} BHK already occupied");
            }
            else if(residents.Any(r => r.flatNo == fltno))
            {
                //Do Nothing
            }
            //Checks the flatsize range
            else if(fltsze >= 3 || fltsze < 1)
            {
                //Do Nothing
            }
            else
            {
                residents.Add(new Resident(fltno, fltsze, ownrname, sttus, noofpeple));
                Console.WriteLine("Resident added successfully");
            }
        }

        public List<string> FindStatusWiseTotalNoOfPeople()
        {
            List<string> statusCount = new List<string>();
            int ownerCount =0, tenantCount =0;
            //Getting the total
            foreach(var r in residents)
            {
                if(r.status.ToLower() == "owner")
                {
                    ownerCount += r.noOfPeople;
                }
                if(r.status.ToLower() == "tenant")
                {
                    tenantCount += r.noOfPeople;
                }
            }
            //Adding Count and formatting the string to add into the list.
            statusCount.Add($"Owner#{ownerCount}");
            statusCount.Add($"Tenant#{tenantCount}");
            return statusCount;
        }

        public Resident FindResidentByFlatNo(int fltNo)
        {
            var resident = residents.Find(a => a.flatNo == fltNo); //Getting the flat resident
            //Checks if the resident object returned is not null 
            if(resident != null)
            {
                return resident;
            }
            else
            {
                return null;
            }
        }
    }
    #endregion

}